# OpsHub — deployment, environments and recovery

**Recommendation:** one paid Render web service serving built merchant/platform React bundles and Nest API, one worker from the same immutable image, one paid private PostgreSQL 17 database, private Amazon S3 storage and managed identity/email/error monitoring. [ADR009](adr/ADR-009-deployment.md). This is a proposal; no account, infrastructure, deployment or secret is created here.

## Environment isolation

| Environment | Contract |
|---|---|
| Local | Same database major with real runtime roles/RLS, local worker/queue and synthetic fixtures. Provider mocks; no production secrets/raw customer data. Docker optional where available; equivalent disposable test DB possible |
| Test/CI | Disposable real PostgreSQL with nonowner role tests and fake provider clocks/failures; egress to production provider APIs denied. Short-lived object/mock endpoints and isolated auth stub |
| Staging | Independent database/storage/auth app/provider sandbox or explicitly controlled pilot credentials; mutation egress disabled by default. No production data copy without separate redaction/authorization |
| Production | Dedicated project/workspace/secrets/storage namespace/database; paid restore-capable services, verified connection ownership and reviewed release configuration |
| Preview | Optional short-lived application plus disposable synthetic DB/mocks; no live provider credentials/webhook registrations or shared staging writes. Defer if cost/isolation outweighs benefit |

Use private database address and disable public DB access except explicit temporary reviewed operator need. Web and worker have separate secrets/grants; migration/backup credentials live only in controlled release/operations context. Database grants distinguish tenant runtime, control plane, worker, queue transport, retention and schema owner. Web holds no provider decryption key. Secret rotation/version recovery is documented; encrypted backups without the required protected decryption keys are not recoverable evidence.

[Render service types](https://render.com/docs/service-types) supports background workers and paid Postgres recovery; [private networking](https://render.com/docs/private-network). Region/data residency/latency/plan suitability remain A06/A05, not assumed Cairo hosting. Use established HTTP runtime/image and static asset serving; no serverless timeout dependency for background workflows.

## Release and schema changes

Later authorized implementation uses pinned image/lockfile and compatible web/worker release versions. Controlled one-off migration job takes a release lock, uses schema-owner credentials, verifies target environment/database, and applies reviewed expand/contract changes. Runtime never runs schema synchronization. Deploy compatible expansion before app, delay destructive contraction until approved rollback window/data checks. No production migrations are generated in Phase 4.

Graceful worker shutdown stops accepting dispatch, finishes bounded safe work and records uncertain mutations conservatively. Rolling deploy cannot reclaim expired write leases and resend. A release rollback restores the compatible prior application image; it cannot undo external effects or destructively down-migrate evidence. For incompatible schema/provider failure, stop mutation starts and forward-fix under review while preserving reads/reconciliation. Readiness probes inspect DB/worker protocol versions; provider outage is displayed per capability rather than crashing all reads.

## Backup and restore

Paid Render Postgres currently documents PITR with a plan-dependent window; Free compute lacks that recovery. Select a purchased plan that meets reviewed recovery needs, not a free pilot default. [Recovery documentation](https://render.com/docs/postgresql-backups). Proposed additional encrypted logical exports to private independent storage, object versioning/lifecycle and protected credential-key backup improve recoverability; cadence/retention/RPO/RTO require A06/OP12 approval and actual restore measurement. Do not invent a measured recovery guarantee.

Restore drills use a **new isolated database**, mutation-egress-off worker, synthetic/redacted data handling and no customer messages. Check identity/grants/RLS/FKs, canonical relationships, source assertions/corrections, open action reservations/results, queue/outbox, projection revisions, file integrity and secret key availability. Reapply approved deletion manifests before user access. Backup contains jobs, but restoring jobs is not authorization to replay external writes.

## Protecting external effects across backup rollback

A database restore can forget a mutation that happened after the restore point. Add a minimal **pre-dispatch recovery journal in the already-required private object store**, separate from DB backup rollback. Before any provider business write, record an immutable conditional-create marker containing environment, merchant/objective/intent/effect/attempt IDs, intent hash, reviewed authority reference and provider connection/correlation ID; no customer payload or token. Confirm durable creation before sending. A journal failure blocks dispatch; an uncertain write/read remains unknown. Result references are appended separately. This adds one small write per effect and a storage availability dependency, justified by irreversible effects.

Use restricted append/read recovery permissions, environment-separated prefix, conditional-create enforcement and version/deletion protection. Conditional S3 writes prevent overwriting an existing marker; they do not make S3+Postgres+provider an atomic transaction. [S3 conditional writes](https://docs.aws.amazon.com/AmazonS3/latest/userguide/conditional-writes.html). Marker presence means **may have sent**, never proof of success.13's journal is a recovery safety record, not a general event bus or second business database.

After restore, disable all merchant mutation egress and automatic action queue dispatch. Quarantine every restored approved/started effect that may predate missing dispatch history; enumerate the complete independently retained journal and provider changes over the recovery gap, rebuild missing objective reservations/unknown-effect records and reconcile positive identities. Expired membership/invitation/session and retention policies are also rechecked. Imported provider objects without known local approval stay source-reported discrepancies, not retroactively authorized effects.

No automatic resume until restored reservations, journal coverage, active authority and qualified provider evidence agree. Missing journal coverage/storage or unprovable no-effect keeps affected objectives blocked and escalated; do not reset them because the restored database calls them Approved. This cannot prevent independent provider-account actions; A01's booking ownership plus provider reconciliation remain required. Test this scenario in 14. The deployment/restore runbook is a design contract, not executed migration or recovery work.
