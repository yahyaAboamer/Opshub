# ADR-007 — PostgreSQL jobs with transactional work records

## Status

**Proposed — pending human Phase 4 architecture review.** 14 October 2026. Does not authorize implementation or deployment.

## Context

Sync/reconciliation/projections/export need durable background execution without a datastore fleet.

## Decision

pg-boss transport plus module-owned transactional outbox_work and idempotent handlers; one worker/scheduler initially, fair account budgets.

## Alternatives

Redis/BullMQ; managed queue plus scheduler; distributed orchestration.

## Consequences

Shared DB capacity/library maintenance dependency; authoritative business work IDs ease transport replacement. Redelivery cannot repeat a started mutation.

Details and evidence: [architecture chapter](../07-background-jobs-and-reconciliation.md). Approved OD01–OD09 remain mandatory; unresolved qualifications are in [17](../17-open-architecture-decisions.md).
